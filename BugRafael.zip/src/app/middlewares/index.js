import log from './log';

export default [log];
