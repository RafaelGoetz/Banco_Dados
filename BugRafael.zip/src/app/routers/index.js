import student from './student';
import studentGrade from './studentGrade';


export default [student, studentGrade];