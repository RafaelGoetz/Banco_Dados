import BaseServices from './BaseServices';
import { QueryTypes } from 'sequelize';


export default class StudentGradeService extends BaseServices {
  constructor() {
    super();
  }

  async get() {

  }
  async show() {

  }

  async create() {

  }
  
  async update(){

  }

  async delete() {

  }

}